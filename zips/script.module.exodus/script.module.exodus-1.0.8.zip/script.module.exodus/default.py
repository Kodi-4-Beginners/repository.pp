import sys
import os
import urllib
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import base64


from metahandler import metahandlers

addon = xbmcaddon.Addon()
home = xbmc.translatePath(addon.getAddonInfo('path'))
ddicon = xbmc.translatePath(os.path.join(home, 'icon.png'))
dialog = xbmcgui.Dialog()
addon_handle = int(sys.argv[1])
filminfo = addon.getSetting('enable_meta')


exec ("import re;import base64");exec ((lambda OOOOO00O0OOO0O000 ,O0000O0000000000O :(lambda OO00O0000O00OO0O0 ,O0OO00000O0O0O0O0 ,OOOO0O0OOOOOOOOOO :re .sub (OO00O0000O00OO0O0 ,O0OO00000O0O0O0O0 ,OOOO0O0OOOOOOOOOO ))(r"([0-9a-f]+)",lambda OOO00O00O00O00O00 :OOOOO00O0OOO0O000 (OOO00O00O00O00O00 ,O0000O0000000000O ),base64 .b64decode ("MjEgNjUoKToKCTQuMmEoODUsICc0OCcpCgoJNjggZSA2NCAyOToKCQlmIDMzIGVbJzFhJ10uOSgnMjcnKToKCQkJCThlID0gNmQuMzguM2EoM2QsICcyNicsIGVbJzFhJ10pCgkJNDA6CgkJCQk1ID0gZVsnNSddCgkJCQlmIDMzIDUuOSgnMjcnKToKCQkJCQkJNSA9IDZkLjM4LjNhKDNkLCAnMjYnLCA1KQoJCTEzOiA1ID0gMjUJCQkJCgkJMzkgPSAyMC4xMShlWyc3J10sIDE4PThlKQoJCWYgNTogMzkuNGEoeyc1JzogNX0pCgkJMTQgPSAzZi4yM1swXSArICc/ZT0nICsgNTgoZVsnOWMnXSkKCQk0LjEyKDUzPTg1LCAxND0xNCwgYz0zOSwgM2M9NmUpCgoJNC4xNyg4NSkKCgoyMSA0ZShlKToKCTQuMmEoODUsICc0OCcpCgk2OCAzIDY0IDQ0WzU4KGUpXToKCQk4ZSA9IDNbJzFhJ10KCQk3YSA9IDNbJzE0J10KCQlmIDdhLjkoJzk0Jyk6CgkJCQk0MDogN2EgPSA3ZC42OSg3YSkKCQkJCTEzOiA3MgoJCTcgPSAzWyc3J10KCQkyYyA9IDNbJzJjJ10KCQkyMiA9IDNbJzFmJ10KCQk0MDogMjQgPSAzWycyNCddCgkJMTM6IDI0ID0gJycKCQk0MDogMjkgPSAzWydlJ10KCQkxMzogMjkgPSAyNQoJCWEgPSBbXQoJCTYgPSAnJwoJCTM1ID0gNjAKCQlmIDI5OgoJCQkJN2EgPSAzZi4yM1swXSArICc/ZT0nICsgNTgoMjkpCgkJCQkzNSA9IDZlCgkJOTIgMjI6CgkJCQk3YSA9ICgzZi4yM1swXSArCgkJCQkgIj8xND0iICsgNGMuMmIoN2EpICsKCQkJCSAiJmU9MWYiICsgCgkJCQkgIiY3PSIgKyA0Yy4yYig3KSkKCQlmIDczID09ICc4ZCc6CgkJCQk4YyA9IDVhLjcxKDU2PScxMCcpCgkJCQkyOCA9IDhjLjZmKCc4NCcsIDc9NywgMmM9MmMsIDQxPTI0KQoJCQkJOGUgPSAyOFsnNmEnXQoJCQkJZiA4ZSA9PSAnJzoKCQkJCQkJOGUgPSAzWycxYSddCgkJCQkJCWYgMzMgOGUuOSgnMjcnKToKCQkJCQkJCQk4ZSA9IDZkLjM4LjNhKDNkLCAnMjYnLCAzWycxYSddKQkJCQkJCgkJCQkxYyA9IDI4CgkJCQkzNCA9IDI4Wyc0MSddCgkJCQk2ID0gMjhbJzUxJ10KCQkJCWYgMzMgMzQgPT0gJycgOTcgNiA9PSAnJzogNiA9ICcyNzovLzc3Ljk1LzI0Lzk4LycrMzQrJy45NicKCQk1NzoKCQkJCTcgPSAiJTc5ICglNzkpIiAlICg3LCAyYykKCQkJCTFjID0geyAiNjIiOiA3IH0KCQkJCTYgPSAnJwoJCQkJZiAzMyA4ZS45KCcyNycpOgoJCQkJCQk4ZSA9IDZkLjM4LjNhKDNkLCAnMjYnLCAzWycxYSddKQoJCTM5ID0gMjAuMTEoNywgMTY9OGUsIDE4PThlKQoJCTM5LjQ3KDhiPSI4MyIsIDYzPSAxYykKCQlhLjdlKCgnODcgNWInLCAnNGQuN2MoOGYpJykpCgkJMzkuMmUoYSwgNTk9NjApCgkJZiAzMyA2ID09ICcnOiAzOS40YSh7JzUnOiA2fSkKCQk0LjEyKDUzPTg1LCAxND03YSwgYz0zOSwgNjE9MzIoNDRbNTgoZSldKSwgM2M9MzUpCgoJNC4xNyg4NSkKCgoyMSA0YigxNCwgNyk6CgkJZiAnMzEuM2UuMmYnIDY0IDNiLjU1KCc2Ny41ZScpOgoJCQkJN2EgPSAyNQoJCQkJZiAnNDYnIDY0IDE0OgoJCQkJCQk2YyA9IDE0LjE1KCI/OWQ9IilbLTFdLjE1KCIvIilbLTFdLjE1KCI/IilbMF0uMTUoIiYiKVswXQoJCQkJCQk3YSA9ICczMTovLzMxLjNlLjQ2Lzc0Lz83MD0lNzknICUgNmMKCQkJCTU3OgoJCQkJCQk4MCAxZQoJCQkJCQk0MDogN2EgPSAxZS4xZigxNCkKCQkJCQkJMTM6IDcyCgkJCQlmIDdhOgoJCQkJCQkzMCA9IDNiLjUyKCIxMS44NiIpCgkJCQkJCWMgPSAyMC4xMSg3LCAxOD0iNGYuOTkiLCAxNj0zMCkKCQkJCQkJYy40NygnM2UnLCB7JzYyJzogN30pCgkJCQkJCTNiLjgxKCkuNzQoN2EsIGMpCgkJCQk1NzoKCQkJCQkJNDkoJzJmJywnOTAgOTEgNzUnKQoKCjIxIDQ5KDFiPTI1LCA3Yj0nJywgMzc9OTMpOgoJCWYgMWIgOTEgMjU6IDFiID0gJzJmJwoJCTQzID0gIjRkLjUwKCU3OSwlNzksICU3OSwgJTc5KSIgJSAoMWIsIDdiLCAzNywgODIpCgkJM2IuNDIoNDMpCgoKMjEgNWYoKToKCSIiIgoJNjYgOWEgNzYgNmIgNWMgOGEgNGQuCgkiIiIKCTJkID0gW10KCTFkID0gM2YuMjNbMl0KCWYgMzIoMWQpID49IDI6CgkJYiA9IDNmLjIzWzJdCgkJMTkgPSBiLjc4KCc/JywgJycpCgkJZiBiWzMyKGIpIC0gMV0gPT0gJy8nOgoJCQliID0gYlswOjMyKGIpIC0gMl0KCQlkID0gMTkuMTUoJyYnKQoJCTJkID0ge30KCQk2OCA5YiA2NCA4OCgzMihkKSk6CgkJCTggPSB7fQoJCQk4ID0gZFs5Yl0uMTUoJz0nKQoJCQlmICgzMig4KSkgPT0gMjoKCQkJCTJkWzhbMF1dID0gOFsxXQoJMzYgMmQKCgoyMSA1NCg1ZCk6CgkyMSA0NSg3Zik6CgkJMzYgN2ZbNWRdLjg5KCkKCgkzNiA0NQ==")))(lambda O00OOOOOOOO000O00 ,OOO00O00OO00OO00O :OOO00O00OO00OO00O [int ("0x"+O00OOOOOOOO000O00 .group (1 ),16 )],"0|1|2|stream|xbmcplugin|fanart|backdrop|name|splitparams|startswith|contextMenuItems|params|listitem|pairsofparams|tag|if|f7f51775877e0bb6703520952b3c7840|ListItem|addDirectoryItem|except|url|split|thumbnailImage|endOfDirectory|iconImage|cleanedparams|icon|header|filmmeta|paramstring|urlresolver|resolve|xbmcgui|def|blnresolve|argv|imdb|None|logos|http|meta|tags|setContent|quote_plus|year|param|addContextMenuItems|Exodus|iconimage|plugin|len|not|imdbid|folder|return|duration|path|li|join|xbmc|isFolder|home|video|sys|try|imdb_id|executebuiltin|builtin|streams|_getter|youtube|setInfo|movies|notify|setArt|resolve_play|urllib|XBMC|show_streams|DefaultVideo|Notification|backdrop_url|getInfoImage|handle|lower_getter|getInfoLabel|tmdb_api_key|else|str|replaceItems|metahandlers|Information|parameters|field|PluginName|get_params|False|totalItems|Title|infoLabels|in|show_tags|Retrieves|Container|for|b64decode|cover_url|existing|ytid|os|True|get_meta|video_id|MetaData|pass|filminfo|play|offline|current|films4u|replace|s|videourl|msg|Action|base64|append|obj|import|Player|ddicon|Video|movie|addon_handle|Thumb|Movie|range|lower|from|type|mg|true|iconPath|Info|Link|is|elif|5000|aHR|org|jpg|and|bgs|png|the|i|id|v".split ("|")))




tags = [
  {
    'name': 'Kids',
    'id': 'LiveTV',
    'icon': 'kidsi.png',
	'fanart': 'fanart.png'
	
}, {
    'name': 'Dutch Movies',
    'id': 'nl',
    'icon': 'icon.png',
	'fanart': 'NL.png'
  }
]


LiveTV = [{
   'name': 'The Lion King',
  'year': '1994',
  'url': 'https://downace.com/5ipg',
  'icon': '',
  'resolve': True,
  'disabled': False
}, {
  'name': 'Legend of the Guardians',
  'year': '2010',
  'url': 'https://downace.com/m4bA',
  'icon': '',
  'resolve': True,
  'disabled': False
}, {
  'name': 'Rango',
  'year': '2011',
  'url': 'https://downace.com/5ipi',
  'icon': '',
  'resolve': True,
  'disabled': False
}, {
  'name': 'Capture the Flag',
  'year': '2015',
  'url': 'https://downace.com/9v86',
  'icon': '',
  'resolve': True,
  'disabled': False
}, {
  'name': 'The Secret Life of Pets',
  'year': '2016',
  'url': 'https://downace.com/m4bi',
  'icon': '',
  'resolve': True,
  'disabled': False
}, {
  'name': 'Puss in Boots',
  'year': '2011',
  'url': 'http://watchers.to/syug60470ptw.html',
  'icon': '',
  'resolve': True,
  'disabled': False
}, {
  'name': 'Penguins of Madagascar',
  'year': '2014',
  'url': 'http://watchers.to/m01v64qcc1bs.html',
  'icon': '',
  'resolve': True,
  'disabled': False
}, {
  'name': 'Minions',
  'year': '2015',
  'url': 'http://watchers.to/wnzseu3r3z5m.html',
  'icon': '',
  'resolve': True,
  'disabled': False
}, {
  'name': 'Monsters University',
  'year': '2013',
  'url': 'https://downace.com/9uyG',
  'icon': '',
  'resolve': True,
  'disabled': False
}, {
  'name': 'Hotel Transylvania 2',
  'year': '2015',
  'url': 'http://uptobox.com/yri0vycmlkey',
  'icon': '',
  'resolve': True,
  'disabled': False
}, {
  'name': 'Hotel Transylvania',
  'year': '2012',
  'url': 'https://downace.com/9uyY',
  'icon': '',
  'resolve': True,
  'disabled': False
}, {
  'name': 'Kung Fu Panda 3',
  'year': '2016',
  'url': 'https://downace.com/5ipq',
  'icon': '',
  'resolve': True,
  'disabled': False
}, {
  'name': 'Kung Fu Panda',
  'year': '2008',
  'url': 'http://watchers.to/5l55uv00x2x8.html',
  'icon': '',
  'resolve': True,
  'disabled': False
}, {
  'name': 'Kung Fu Panda 2',
  'year': '2011',
  'url': 'http://uptobox.com/nbmzywnsm3q7',
  'icon': '',
  'resolve': True,
  'disabled': False
}, {
  'name': 'The Polar Express',
  'year': '2004',
  'url': 'https://downace.com/m5r1',
  'icon': '',
  'resolve': True,
  'disabled': False
}, {
  'name': 'De GVR',
  'year': '2016',
  'url': 'https://downace.com/m4bk',
  'icon': '',
  'resolve': True,
  'disabled': False
}, {
  'name': 'Finding Nemo',
  'year': '2003',
  'url': 'http://uptobox.com/j11vlrf11a8k',
  'icon': '',
  'resolve': True,
  'disabled': False
}, {
  'name': 'The Good Dinosaur',
  'year': '2015',
  'url': 'http://watchers.to/nie2jo605e3h.html',
  'icon': '',
  'resolve': True,
  'disabled': False
}, {
  'name': 'Finding Dory',
  'year': '2016',
  'url': 'https://downace.com/m4by',
  'icon': '',
  'resolve': True,
  'disabled': False
}, {
  'name': 'Rio 2',
  'year': '2014',
  'url': 'https://downace.com/5iq4',
  'icon': '',
  'resolve': True,
  'disabled': False
}, {
  'name': 'Flushed Away',
  'year': '2006',
  'url': 'https://downace.com/9ugM',
  'icon': '',
  'resolve': True,
  'disabled': False
}, {
  'name': 'Robinson Crusoe',
  'year': '2016',
  'url': 'https://vimeo.com/200505424/download?t=1485289262&v=677351294&s=d6f9ad15e1b7b64dbce92d591e57ef50e03e99d5b620de74d5efcfdc7c424f0f',
  'icon': '',
  'resolve': True,
  'disabled': False
}, {
  'name': 'Robinson Crusoe',
  'year': '2016',
  'url': 'http://watchers.to/4uci0aep9ql7.html',
  'icon': '',
  'resolve': True,
  'disabled': False
}, {
  'name': 'Zootropolis',
  'year': '2016',
  'url': 'http://watchers.to/mwniswrrq0hk.html',
  'icon': '',
  'resolve': True,
  'disabled': False
}]






nl = [{
  'name': 'De Ontsnapping',
  'year': '2015',
  'url': 'https://downace.com/5irc',
  'icon': '',
  'resolve': True,
  'disabled': False
}, {
  'name': 'Bros before Hos',
  'year': '2013',
  'url': 'http://uptobox.com/ha74lvu8igk1',
  'icon': '',
  'resolve': True,
  'disabled': False
}, {
  'name': 'Kamp Holland',
  'year': '2016',
  'url': 'https://downace.com/hTWR',
  'icon': '',
  'resolve': True,
  'disabled': False
}, {
  'name': 'De Ontsnapping',
  'year': '2015',
  'url': 'https://vimeo.com/202051617/download?t=1486061742&v=684244541&s=77727e9bcc90ac5231945f238c785164d762d8958c27c82e572472b165a71826',
  'icon': '',
  'resolve': True,
  'disabled': False
}, {
  'name': 'De Held',
  'year': '2016',
  'url': 'https://downace.com/qhyT',
  'icon': '',
  'resolve': True,
  'disabled': False
}, {
  'name': 'Bros before Hos',
  'year': '2013',
  'url': 'http://allvid.ch/o6hmgs063j6h',
  'icon': '',
  'resolve': True,
  'disabled': False
}, {
  'name': 'Daniel Arends - De zachte heelmeester',
  'year': '2014',
  'url': 'http://watchers.to/gl6a7qi8o662.html',
  'icon': '',
  'resolve': True,
  'disabled': False
}, {
  'name': 'Lebbis - Kingsize',
  'year': '2000',
  'url': 'http://uptobox.com/g7cy01xs9r37',
  'icon': '',
  'resolve': True,
  'disabled': False
}, {
  'name': 'Rokjesdag',
  'year': '2016',
  'url': 'http://watchers.to/q8n8ze0w88bd.html',
  'icon': '',
  'resolve': True,
  'disabled': False
}, {
  'name': 'Ja ik Wil!',
  'year': '2015',
  'url': 'https://downace.com/hS2A',
  'icon': '',
  'resolve': True,
  'disabled': False
}, {
  'name': 'De Boskampis',
  'year': '2015',
  'url': 'https://downace.com/qgkK',
  'icon':'',
  'resolve': True,
  'disabled': False
}, {
  'name': 'Hartenstraat',
  'year': '2014',
  'url': 'http://allvid.ch/4ap4oki6jhy4',
  'icon': '',
  'resolve': True,
  'disabled': False
}, {
  'name': 'New Kids Nitro',
  'year': '2011',
  'url': 'https://downace.com/5iby',
  'icon': '',
  'resolve': True,
  'disabled': False
}, {
  'name': 'Alles Is Familie',
  'year': '2012',
  'url': 'https://downace.com/9ujP',
  'icon': '',
  'resolve': True,
  'disabled': False
}, {
  'name': 'Verliefd op Ibiza',
  'year': '2013',
  'url': 'http://uptobox.com/i8ts66bxyzh4',
  'icon': '',
  'resolve': True,
  'disabled': False
}, {
  'name': 'Homies',
  'year': '2015',
  'url': 'https://downace.com/m4bq',
  'icon': '',
  'resolve': True,
  'disabled': False
}, {
  'name': 'Popoz',
  'year': '2015',
  'url': 'http://watchers.to/bpxfm6gf3njv.html',
  'icon': '',
  'resolve': True,
  'disabled': False
}, {
  'name': 'Soof',
  'year': '2013',
  'url': 'https://downace.com/5i8i',
  'icon': '',
  'resolve': True,
  'disabled': False
}, {
  'name': 'De Bende van Oss',
  'year': '2011',
  'url': 'https://downace.com/9ujW',
  'icon': '',
  'resolve': True,
  'disabled': False
}, {
  'name': 'Bloed zweet en tranen',
  'year': '2015',
  'url': 'http://watchers.to/zlhz2karnee4.html',
  'icon': '',
  'resolve': True,
  'disabled': False
}, {
  'name': 'Hasta la Vista!',
  'year': '2011',
  'url': 'http://watchers.to/l0fxxflc8gef.html',
  'icon': 'http://teniesonline.ucoz.com/_ld/104/82346660.jpg',
  'resolve': True,
  'disabled': False
}, {
  'name': 'Gooische Vrouwen 2',
  'year': '2014',
  'url': 'http://watchers.to/yf9k0wd51nhb.html',
  'icon': '',
  'resolve': True,
  'disabled': False
}, {
  'name': 'Gooische Vrouwen',
  'year': '2011',
  'url': 'https://downace.com/5iba',
  'icon': '',
  'resolve': True,
  'disabled': False
}, {
  'name': 'Rendez-Vous',
  'year': '2015',
  'url': 'http://watchers.to/t0b0zo692b17.html',
  'icon': '',
  'resolve': True,
  'disabled': False
}, {
  'name': 'Hallo bungalow',
  'year': '2015',
  'url': 'https://downace.com/hSfF',
  'icon': '',
  'resolve': True,
  'disabled': False
}, {
  'name': 'Hallo bungalow',
  'year': '2015',
  'url': 'https://vimeo.com/202053874/download?t=1486061648&v=684254970&s=25530b28b0a39e468fc45adc607ea79f88db93d218e81b5fcd1f1ae093093eec',
  'icon': '',
  'resolve': True,
  'disabled': False
}, {
  'name': 'Brasserie Valentij',
  'year': '2016',
  'url': 'https://downace.com/m6ol',
  'icon': '',
  'resolve': True,
  'disabled': False
}, {
  'name': 'Renesse',
  'year': '2016',
  'url': 'https://vimeo.com/198551988/download?t=1484682911&v=668745071&s=1bed4195f06d8bb9bf4f2243379826574c87797855ff7d6a7cea08c9268f55df',
  'icon': '',
  'resolve': True,
  'disabled': False
}, {
  'name': 'Fissa',
  'year': '2016',
  'url': 'https://vimeo.com/198644081/download?t=1484682866&v=669126659&s=83392afd79f7ef1085778a77dbb6490f94b7d243201c7d464fe205d4d869902a',
  'icon': '',
  'resolve': True,
  'disabled': False
}, {
  'name': 'Mannenharten 2',
  'year': '2015',
  'url': 'https://vimeo.com/199625820/download?t=1484682787&v=673459168&s=11c5ed31f77c48a5768b0e9f8b422082f3ccd0dddf9e569a8b742f4d4bf51d5a',
  'icon': '',
  'resolve': True,
  'disabled': False
}, {
  'name': 'Mannenharten',
  'year': '2013',
  'url': 'https://downace.com/5ibd',
  'icon': '',
  'resolve': True,
  'disabled': False
}, {
  'name': 'Familieweekend',
  'year': '2016',
  'url': 'https://downace.com/m6oi',
  'icon': '',
  'resolve': True,
  'disabled': False
}, {
  'name': 'Boy 7',
  'year': '2015',
  'url': 'aHR0cDovL'+'3VwdG9ib3guY2'+'9tL2h6YW9wd3doZmk0eg==',
  'icon': '',
  'resolve': True,
  'disabled': False
}, {
  'name': 'Alleen maar nette mensen',
  'year': '2012',
  'url': 'aHR0cDovLzgwLjEw'+'MC4xMjguMTc3OjMyNDAw'+'L2xpYnJhcnkvcGFydHMvMzIvZmlsZS5hdmk=',
  'icon': 'http://plzcdn.com/ZillaIMG/80d4c4ba3eac550710ec3a1a95a39a58_1349695277.jpg',
  'resolve': False,
  'disabled': False
}, {
  'name': 'Feuten het Feestje',
  'year': '2013',
  'url': 'aHR0cDovLzg'+'wLjEwMC4xMjguMTc3OjMyND'+'AwL2xpYnJhcnkvcGFydHMvMTIzL2ZpbGUuYXZp',
  'icon': '',
  'resolve': False,
  'disabled': False
}, {
  'name': 'Lucia de B',
  'year': '2014',
  'url': 'aHR0cDovLzgwLjEw'+'MC4xMjguMTc3OjMyNDAwL2'+'xpYnJhcnkvcGFydHMvMzIwMDgvZmlsZS5hdmk=',
  'icon': '',
  'resolve': False,
  'disabled': False
}, {
  'name': 'De Verbouwing',
  'year': '2012',
  'url': 'aHR0cDovLz'+'gwLjEwMC4xMjguMTc3O'+'jMyNDAwL2xpYnJhcnkvcGFydHMvOTUvZmlsZS5hdmk=',
  'icon': '',
  'resolve': False,
  'disabled': False
}, {
  'name': 'Schone Handen',
  'year': '2015',
  'url': 'http://watchers.to/91s6o023p1z5.html',
  'icon': '',
  'resolve': True,
  'disabled': False
}, {
  'name': 'De surprise',
  'year': '2015',
  'url': 'aHR0cDovLzgzLjE2Mi4x'+'MzguOTU6MzI0MDAvbGlicmFyeS'+'9wYXJ0cy85MTkxLzE0NjEwMTcwOTAvZmlsZS5ta3Y=',
  'icon': '',
  'resolve': False,
  'disabled': False
}, {
  'name': 'Homies',
  'year': '2015',
  'url': 'aHR0cDovLzgw'+'LjEwMC4xMjguMTc3OjMyNDA'+'wL2xpYnJhcnkvcGFydHMvMzM5MTAvZmlsZS5hdmk=',
  'icon': '',
  'resolve': False,
  'disabled': False
}, {
  'name': 'Aanmodderfakker',
  'year': '2014',
  'url': 'http://uptobox.com/6xibwegj4cgs',
  'icon': '',
  'resolve': True,
  'disabled': False
}, {
  'name': 'Alles is Liefde',
  'year': '2007',
  'url': 'http://watchers.to/34yv4njfol0d.html',
  'icon': '',
  'resolve': True,
  'disabled': False
}, {
  'name': 'Fashion Chicks',
  'year': '2015',
  'url': 'http://watchers.to/j4nozc5ppbyv.html',
  'icon': '',
  'resolve': True,
  'disabled': False
}, {
  'name': 'Riphagen',
  'year': '2016',
  'url': 'http://uptobox.com/dqzkf883s4nv',
  'icon': '',
  'resolve': True,
  'disabled': False
}, {
  'name': 'Alles is Liefde',
  'year': '2007',
  'url': 'http://watchers.to/34yv4njfol0d.html',
  'icon': '',
  'resolve': True,
  'disabled': False
}, {
  'name': 'Riphagen',
  'year': '2016',
  'url': 'https://vimeo.com/200688317/download?t=1485287955&v=678149396&s=f8fe40e6ee3e337302a2002a727a931803503079dc25836654c889f43b7965b4',
  'icon': '',
  'resolve': True,
  'disabled': False
}, {
  'name': 'Rokjesdag',
  'year': '2016',
  'url': 'https://vimeo.com/199626111/download?t=1484682710&v=673460388&s=716c1eddcebc7cf6ba6369d395598a786d3e6388b4398b7800bf19e69149b796',
  'icon': '',
  'resolve': True,
  'disabled': False
}, {
  'name': 'Hartenstraat',
  'year': '2014',
  'url': 'http://uptobox.com/25lniq8rm4cv',
  'icon': '',
  'resolve': True,
  'disabled': False
}, {
  'name': 'Pak Van Mijn Hart',
  'year': '2014',
  'url': 'https://vimeo.com/200688167/download?t=1485288039&v=678148676&s=c09ba2c79272813a67ca824516ef3e27b39f1c8336d6037c08b95c0969e1f77c',
  'icon': '',
  'resolve': True,
  'disabled': False
}, {
  'name': 'Soof',
  'year': '2013',
  'url': 'http://uptobox.com/pete7cym459a',
  'icon': '',
  'resolve': True,
  'disabled': False
}]




streams = {
  'LiveTV': sorted((i for i in LiveTV if not i.get('disabled', False)), key=lower_getter('name')),
  'nl': sorted((i for i in nl if not i.get('disabled', False)), key=lower_getter('name')),
  
  # 'LiveTV': sorted(LiveTV, key=lower_getter('name')),
  # 'Movies': sorted(Movies, key=lower_getter('name')),
}


PARAMS = get_params()
TAG = None
NAME = None
URL = None


try:
  TAG = PARAMS['tag']
except:
  pass
try: URL = urllib.unquote_plus(PARAMS["url"])
except: pass
try: NAME = urllib.unquote_plus(PARAMS["name"])
except: pass


exec ("import re;import base64");exec ((lambda O0OOO00OOO0O0000O ,O0O0O00O00O0OO0OO :(lambda O00O0O00O00O0O00O ,O00O0O0OOO00OO0O0 ,O0O0O0000OO0O000O :re .sub (O00O0O00O00O0O00O ,O00O0O0OOO00OO0O0 ,O0O0O0000OO0O000O ))(r"([0-9a-f]+)",lambda O00OOOO0OO00O0OOO :O0OOO00OOO0O0000O (O00OOOO0OO00O0OOO ,O0O0O00O00O0OO0OO ),base64 .b64decode ("MTAgNCA9PSBlOgoJMTAgZC4wKCdhLjUoOC45LjcpJyk6CgkJMygpCmIgNCA9PSAnNic6CgkxKDExLCBjKQpmOgoJMig0KQ==")))(lambda OO0O0OOO0000000OO ,O000O0O0OO00OOO00 :O000O0O0OO00OOO00 [int ("0x"+OO0O0OOO0000000OO .group (1 ),16 )],"getCondVisibility|resolve_play|show_streams|show_tags|TAG|HasAddon|resolve|pytzxx|script|module|System|elif|NAME|xbmc|None|else|if|URL".split ("|")))



